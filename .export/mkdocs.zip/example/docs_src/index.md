# Torillic example wiki

Welcome! Here I've put together a few basic resources to show how you can use mkdocs with torillic to make a professional looking wiki for your world / campaign.