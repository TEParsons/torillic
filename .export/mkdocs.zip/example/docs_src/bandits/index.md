# Bandit encounter
Session a bit boring? Let's fight some bandits! Classic TTRPG stuff!