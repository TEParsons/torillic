# Dragon encounter
Fight through hoards of kobold with humanoid cultists scattered throughout to take on their master: An adult blue dragon.
